﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Text;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using System.Drawing.Imaging;
using OpenQA.Selenium.Firefox;
using System.Windows.Forms;
//using OpenQA.Selenium.Support.UI;


namespace EdgarExtractor
{

    class Program
    {
        //static int fileCount = 0;
        
        
        public static void downloadFile(string ftpFullPath, string cik, string ftpFilePath, string ticker, string fyear)
        {

            string myUserID = "anonymous";
            string myPassword = "student@contoso.com";

            FtpDownload(ftpFilePath, myUserID, myPassword, ftpFullPath, cik, ticker, fyear);
        }

        public static void FtpDownload(string name, string userid, string password, string ftpfullpath, string cik, string ticker, string fyear)
        {
            // Targeted file and server
            //string ftpfullpath = "
            string ffp = ftpfullpath.Replace("http://www.sec.gov/Archives/", "ftp://ftp.sec.gov/");
            ffp = ftpfullpath.Replace("https://www.sec.gov/Archives/", "ftp://ftp.sec.gov/");

            // Get the object used to communicate with the server.
            FtpWebRequest request = (FtpWebRequest)WebRequest.Create(ffp);

            request.UsePassive = false;

            request.Method = WebRequestMethods.Ftp.DownloadFile;

            request.Credentials = new NetworkCredential(userid, password);

            FtpWebResponse response = (FtpWebResponse)request.GetResponse();
            Stream responseStream = response.GetResponseStream();

            name = name.Replace(".txt", ".html");
            string directory = @"c:\\ALL\" + ticker + @"\";


            name = fyear + "_" + ticker + "_" + name;

            using (var fileStream = File.Create(directory + name))
            {
                responseStream.CopyTo(fileStream);
            }

        }

        public static void searchTenK(int i, int ii, OpenQA.Selenium.Firefox.FirefoxDriver driver, string cik, string ticker)
        {
            string xpath_search = "//*[@id='interactiveDataBtn']";
               

            var click = driver.FindElementByXPath(xpath_search);

            string date = driver.FindElementByXPath("//*[@id='seriesDiv']/table/tbody/tr[8]/td[4]").Text;

            DateTime myDate = Convert.ToDateTime(date);

            string year = myDate.Year.ToString();

            click.Click();

            string xpath_download = "html/body/div[5]/table/tbody/tr[1]/td/a[2]";

            var download = driver.FindElementByXPath(xpath_download);
            string href = download.GetAttribute("href");

            using (WebClient webClient = new WebClient())
            {
                webClient.DownloadFile(href, @"c:\\All\" + ticker+ @"\" + year + "_" + ticker + ".xls");
            }

            //driver.Navigate().GoToUrl(href);
           // FirefoxProfile.SetPreference("browser.helperApps.neverAsk.saveToDisk", "application/octet-stream doc xls pdf txt");
            //download.Click();
            //driver.SwitchTo
            //driver.Keyboard.SendKeys(System.Windows.Forms.Keys.Enter);
            //FirefoxProfile.SetPreference("browser.helperApps.alwaysAsk.force", false);
            //FirefoxProfile.SetPreference("services.sync.prefs.sync.browser.download.manager.showWhenStarting", false)
            //driver.SwitchTo().Window(driver.CurrentWindowHandle);
            //driver.SwitchTo().ActiveElement().SendKeys(Keys.Enter);
            //driver.SwitchTo().Alert().SendKeys(Keys.Tab);
            //driver.SwitchTo().Alert().SendKeys(Keys.Enter);
            //driver.Keyboard.SendKeys(Keys.Enter);

            

            //var result = driver.FindElementsByTagName("tr");


            //string total = "";
            //string res = "";
            //try
            //{
            //    foreach (var rr in result)
            //    {
            //        total += rr.Text;
            //        if (rr.Text.Contains("Complete submission text file"))
            //        {
            //            string fdate = Convert.ToDateTime(driver.FindElementByXPath("//*[@id='formDiv']/div[2]/div[1]/div[2]").Text).Year.ToString();
            //            var url = rr.FindElement(By.TagName("a"));

            //            url.Click();
            //            string rurl = driver.Url;
            //            int pos = rurl.LastIndexOf("/") + 1;
            //            string fName = rurl.Substring(pos, rurl.Length - pos);



            //            //downloadFile(rurl, cik, fName, ticker, fdate);
            //            break;
            //        }
            //    }
            //}
            //catch (Exception e)
            //{
                
            //}
        }

        public static void Main()
        {
            //fileCount = 0;
            for (int iter = 0; iter < 500; iter++)
            {
                try
                {
                    
                    //string ticker = "msft";
                    //string cik = "0000789019";
                    string ticker = Tickers.tickers[iter];

                    //if (Tickers.tickers.Contains(ticker))
                    //{
                    //    continue;
                    //}

                    string comname = Tickers.tickers[iter];
                    string cik = Ciks.ciks[iter];

                    string dirPath = @"c:\\ALL\" + comname + @"\";
                    if (!Directory.Exists(dirPath))
                    {
                        Directory.CreateDirectory(dirPath);
                    }

                    // Initialize the Chrome Driver
                    using (var driver = new OpenQA.Selenium.Firefox.FirefoxDriver())
                    {
                        for (int startCount = 0; startCount < 600; startCount += 10)
                        {
                            string surl = "https://www.sec.gov/cgi-bin/browse-edgar?action=getcompany&CIK=" + cik + @"&type=&dateb=&owner=exclude&start=" + startCount + @"&count=10";

                            driver.Navigate().GoToUrl(surl);

                            //Directory.CreateDirectory(@"c:\\AAA\" + cik + @"\");
                            for (int i = 0; i <= 10; i++)
                            {
                                bool is10k = false;
                                string dr_contents = "//*[@id='seriesDiv']/table/tbody/tr[" + i + "]";

                                var drcont = driver.FindElementsByXPath(dr_contents);

                                foreach (var tr in drcont)
                                {
                                    string txt = tr.Text;
                                    if (txt.Contains("10-K"))
                                    {
                                        is10k = true;
                                    }
                                }
                                if (is10k)
                                {


                                    for (int ii = 0; ii <= 5; ii++)
                                    {
                                        try
                                        {
                                            string tr_contents = "//*[@id='seriesDiv']/table/tbody/tr[" + i + "]/td[" + ii + "]/a";

                                            var trcont = driver.FindElementsByXPath(tr_contents);

                                            searchTenK(i, ii, driver, cik, ticker);
                                            if (i < 10)
                                            {
                                                driver.Navigate().GoToUrl(surl);
                                            }
                                            break;
                                        }

                                        catch (Exception e)
                                        {
                                            System.Diagnostics.Debug.WriteLine("Oh no!" + e);
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                catch
                {
                }
            }
            // Prevent the console window from closing down
           // Console.ReadKey();

        }
    }


}
