﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EdgarExtractor
{
    class AllCiks
    {

                public static string[] allciks = new string[500] {



                }
    }
}
