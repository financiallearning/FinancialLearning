﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Tools.Excel;
using System.IO;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            var dirs = Directory.GetDirectories("C:\\ALL");
            foreach (var dir in dirs)
            {
                var files = Directory.GetFiles(dir);
                foreach (var fl in files)
                {
                    string[] parts = fl.Split('\\');
                    string ticker = parts[2];
                    string year = parts[3].Split('_')[0];
                    string fileName = ticker + "_" + year;
                    string fullName = @"C:\\GoodData\\" + fileName + ".csv";

                    Microsoft.Office.Interop.Excel.Application excelApp = new Microsoft.Office.Interop.Excel.Application();
                    try
                    {
                        Dictionary<string, string> ensemble = new Dictionary<string, string>();
                        Microsoft.Office.Interop.Excel.Workbook workBook = excelApp.Workbooks.Open(fl);
                        foreach (var worksheet in workBook.Worksheets)
                        {
                            foreach (Microsoft.Office.Interop.Excel.Worksheet sheet in workBook.Worksheets)
                            {
                                string sheet_name = sheet.Name.ToLower();
                                if (sheet_name.Contains("consolidated") || sheet_name.Contains("statement"))
                                {
                                    foreach (Microsoft.Office.Interop.Excel.Range row in sheet.UsedRange.Rows)
                                    {

                                        bool firstCol = true;
                                        bool secondCol = false;
                                        string ens_key = "";
                                        foreach (Range col in row)
                                        {

                                            foreach (Microsoft.Office.Interop.Excel.Range item in col.Cells)
                                            {

                                                string value = Convert.ToString(item.Value);
                                                if (secondCol)
                                                {
                                                    if (value != null)
                                                    {
                                                        //csv.Append(cc);
                                                        string mod = value.Replace(",", "");
                                                        ensemble[ens_key] = mod;

                                                    }
                                                    secondCol = false;
                                                }
                                                if (firstCol)
                                                {
                                                    //colsList.Add(cc);
                                                    //col_csv.Append(cc);
                                                    if (value != null)
                                                    {
                                                        string mod = value.Replace(",", "");
                                                        ensemble[mod] = "";
                                                        ens_key = mod;
                                                    }
                                                    firstCol = false;
                                                    secondCol = true;
                                                }

                                            }
                                        }
                                    }
                                }
                            }
                        }
                        StringBuilder bigString = new StringBuilder();
                        foreach (KeyValuePair<string, string> item in ensemble)
                        {
                            float n;
                            bool isNum = float.TryParse(item.Value, out n);

                            if (isNum)
                                bigString.Append(item.Key + ",");

                        }
                        bigString.Append("\n");
                        foreach (KeyValuePair<string, string> item in ensemble)
                        {
                            float n;
                            bool isNum = float.TryParse(item.Value, out n);

                            if (isNum)
                                bigString.Append(item.Value + ",");
                        }

                        File.WriteAllText(fullName, bigString.ToString());

                    }
                    catch
                    {
                    }

                    excelApp.Quit();
                }
            }

        }
    }
}
